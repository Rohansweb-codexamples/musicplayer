# PLEASE READ THIS BEFORE USING



App Name: Music player (When searching type 'Player' and you should see something like 'player.exe'\*)



1.\*Open the file ( look from steps above )

2.Select a file \*\*

3\. Press play

&nbsp;    NEXT STEPS(\*\*\*)















# THANKS!

\*\* You can browse the files app. MP3s only!

\*\*\* You can press 'pause' to pause and 'stop' to stop the song and play another file.

Now that's Thanks!

**Good luck!**







